$(document).ready(function(){
    $('.chosen-select').chosen({width: "100%"});
    $('.i-checks').iCheck({
        checkboxClass: 'icheckbox_square-green',
        radioClass: 'iradio_square-green',
    });
    $(".select2_demo_1").select2({
        theme: 'bootstrap4',
    });
    $('form').on('submit', function(e){
        if (!$('#machine').val()) {
            e.preventDefault();
            $('#msg_machine').removeClass('d-none');
        }
        if (!$('#workcell').val()) {
            e.preventDefault();
            $('#msg_workcell').removeClass('d-none');
        }
    });

    $(document).on('change', function() {
        if ($('#machine').val()) $('#msg_machine').addClass('d-none');
        if ($('#workcell').val()) $('#msg_workcell').addClass('d-none');
    });
})