$(document).ready(function(){
    $('.i-checks').iCheck({
        checkboxClass: 'icheckbox_square-green',
        radioClass: 'iradio_square-green',
    });
    $('form').on('submit', function(e){
        if (!$('#partnumber').val()) {
            e.preventDefault();
            $('#msg_partnumber').removeClass('d-none');
        }
        if (!$('Textarea').val().trim()) {
            e.preventDefault();
            $('#msg_desc').removeClass('d-none');
        }
    });
    
    $(document).on('change', function() {
        if ($('#partnumber').val()) $('#msg_partnumber').addClass('d-none');
        if ($('Textarea').val()) $('#msg_desc').addClass('d-none');
    });
})