$(document).ready(function(){
    $('.chosen-select').chosen({width: "100%"});

    $('form').on('submit', function(e){
        if (!$('#name').val()) {
            e.preventDefault();
            $('#msg_name').removeClass('d-none');
        }
        if (!$('#username').val()) {
            e.preventDefault();
            $('#msg_username').removeClass('d-none');
        }
        if (!$('#role').val()) {
            e.preventDefault();
            $('#msg_role').removeClass('d-none');
        }
        if (!$('#password').val()) {
            e.preventDefault();
            $('#msg_psw').removeClass('d-none');
        }
        if (!$('#repassword').val()) {
            e.preventDefault();
            $('#msg_repsw').removeClass('d-none');
        }
    });
    
    $(document).on('change', function() {
        if ($('#name').val()) $('#msg_name').addClass('d-none');
        if ($('#username').val()) $('#msg_username').addClass('d-none');
        if ($('#role').val()) $('#msg_role').addClass('d-none');
        if ($('#password').val()) $('#msg_psw').addClass('d-none');
        if ($('#repassword').val()) $('#msg_repsw').addClass('d-none');

        $('#password').val() != $('#repassword').val() ? $('#msg_repsw_check').removeClass('d-none') : $('#msg_repsw_check').addClass('d-none');
    });

})